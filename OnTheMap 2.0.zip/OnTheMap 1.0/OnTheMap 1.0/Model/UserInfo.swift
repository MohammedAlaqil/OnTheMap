//
//  UserInfo.swift
//  OnTheMap 1.0
//
//  Created by M7md on 26/05/2019.
//  Copyright © 2019 Udacity. All rights reserved.
//

import Foundation

struct UserInfo {
    var firstName : String? = ""
    var lastName : String? = ""
    var key : String? = ""
}
